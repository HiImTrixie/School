#include <iostream>

//no clue
struct list{
    int n;
    int *n;
};

